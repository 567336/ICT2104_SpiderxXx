#include "servo.h"
#include "pca9685.h"

SERVO gast_ServoArray[SERVO_MAX_NUM];
